def preprocess_container(container):

	return container